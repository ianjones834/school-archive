public enum TransactionType {
  Debit,
  Credit
}