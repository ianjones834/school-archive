#include<iostream>
using namespace std;

int readData(int[], int);
void sortData(int[], int);
void printData(int[], int);
