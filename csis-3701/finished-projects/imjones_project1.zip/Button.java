public enum Button {
	p,
	i,
	o,
	m,
	u,
	d,
	c,
	f
}